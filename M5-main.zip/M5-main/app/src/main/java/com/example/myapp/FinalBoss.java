package com.example.myapp;

public class FinalBoss extends Enemy {
    public FinalBoss () {
        this.type = "FinalBoss";
        this.health = 250;
        this.damage = 100;
    }
}